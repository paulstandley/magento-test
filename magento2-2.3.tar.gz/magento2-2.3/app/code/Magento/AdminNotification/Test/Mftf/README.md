# Admin Notification Functional Tests

The Functional Test Module for **Magento Admin Notification** module.
