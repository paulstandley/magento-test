# Amqp Store

**AmqpStore** provides ability to specify store before publish messages with Amqp.
